Properties defined in this directory here will be shared across 
all profiles not overriding them.
