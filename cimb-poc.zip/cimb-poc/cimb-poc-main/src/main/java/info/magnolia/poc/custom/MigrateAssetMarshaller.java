package info.magnolia.poc.custom;

import javax.jcr.Node;
import javax.jcr.RepositoryException;

public class MigrateAssetMarshaller {



    public void marshallNode(final Node node, MigrateAsset asset) throws RepositoryException {
        System.out.println("Please provide your logic to store data here");
    }

  

}
